#!/bin/bash
java --module-path libs --module cotuba.cli/cotuba.cli.Main "$@"
